-- =============================================
-- Módulo: Motor de Cálculo (Factor SKU + Patrón Horario)
-- Funciones: fn_plh_FactoresSKU, fn_plh_PatronHorario
-- SPs: plh_mrf_CalcularMotorMes, plh_mrf_EliminarMotorMes
-- Base de datos: sm_backoffice_op
-- =============================================

USE [sm_backoffice_op];
GO

-- ─── Función: Factor SKU ─────────────────────────────────────────────────────
-- Factor_SKU = Consumo_SKU_Mes_Ref / (Venta_Neta_Total_Tienda_Mes_Ref / 1000)
-- Retorna el factor por SKU activo para la tienda en el mes de referencia.

CREATE OR ALTER FUNCTION [plh].[fn_plh_FactoresSKU]
(
    @TiendaCodigo   INT,
    @CodigoNeg      NVARCHAR(10),
    @AnioRef        INT,
    @MesRef         INT
)
RETURNS TABLE
AS
RETURN
(
    WITH
    Rango AS (
        SELECT
            DATEFROMPARTS(@AnioRef, @MesRef, 1)                    AS fecha_inicio,
            DATEADD(MONTH, 1, DATEFROMPARTS(@AnioRef, @MesRef, 1)) AS fecha_fin
    ),
    DataArea AS (
        SELECT n.neg_referencia1 AS data_area_id
        FROM plh.Vw_plh_neg_Negocios n
        WHERE CAST(n.neg_codigo AS NVARCHAR(20)) = @CodigoNeg
    ),
    VentasPorSku AS (
        SELECT
            cat.cat_pro_codigo                              AS pro_codigo,
            ISNULL(SUM(g.Cantidad * rd.Cantidad_Item), 0)  AS cantidad_sku
        FROM plh.plh_cat_catalogo_productos cat
        CROSS JOIN Rango r
        LEFT JOIN plh.Receta_detalle rd
            ON  rd.Codigo_Item = ISNULL(cat.cat_pro_sustituto_codigo, cat.cat_pro_codigo)
            AND rd.Codigo_Item <> CAST(rd.Id_Receta AS VARCHAR(50))
            AND rd.DataAreaId  = (SELECT data_area_id FROM DataArea)
            AND rd.Modificador <> 1
        LEFT JOIN plh.Vw_Vista_Consumo g
            ON  CAST(g.ITEM AS VARCHAR(50)) = CAST(rd.Id_Receta AS VARCHAR(50))
            AND g.LC_UNIT   = @TiendaCodigo
            AND g.Cantidad  > 0
            AND g.LC_DOB   >= r.fecha_inicio
            AND g.LC_DOB    < r.fecha_fin
        WHERE cat.cat_codigo_neg    = @CodigoNeg
          AND cat.cat_tienda_codigo IN (0, @TiendaCodigo)
          AND cat.cat_activo        = 1
        GROUP BY cat.cat_pro_codigo
    ),
    VentaNeta AS (
        SELECT ISNULL(SUM(vd.venta_diaria), 0) AS total
        FROM plh.plh_Vw_VentaDiaria vd
        CROSS JOIN Rango r
        WHERE vd.tienda = @TiendaCodigo
          AND vd.fecha >= r.fecha_inicio
          AND vd.fecha  < r.fecha_fin
    )
    SELECT
        v.pro_codigo,
        CAST(
            CASE WHEN t.total > 0
                 THEN v.cantidad_sku / (t.total / 1000.0)
                 ELSE 0
            END
        AS DECIMAL(18,6)) AS factor_sku
    FROM VentasPorSku v
    CROSS JOIN VentaNeta t
);
GO

-- ─── Función: Patrón Horario ─────────────────────────────────────────────────
-- Retorna % de ventas por día de semana (1=Lun…7=Dom) y hora (0-23).
-- Porcentaje = Ventas_Hora / Ventas_Dia

CREATE OR ALTER FUNCTION [plh].[fn_plh_PatronHorario]
(
    @TiendaCodigo   INT,
    @CodigoNeg      NVARCHAR(10),
    @AnioRef        INT,
    @MesRef         INT
)
RETURNS TABLE
AS
RETURN
(
    WITH
    Rango AS (
        SELECT
            DATEFROMPARTS(@AnioRef, @MesRef, 1)                    AS fecha_inicio,
            DATEADD(MONTH, 1, DATEFROMPARTS(@AnioRef, @MesRef, 1)) AS fecha_fin
    ),
    DataArea AS (
        SELECT n.neg_referencia1 AS data_area_id
        FROM plh.Vw_plh_neg_Negocios n
        WHERE CAST(n.neg_codigo AS NVARCHAR(20)) = @CodigoNeg
    ),
    VentasBase AS (
        SELECT
            g.LC_DOB                AS fecha_neg,
            CAST(g.HOUR AS TINYINT) AS hora,
            SUM(g.Cantidad)         AS cantidad
        FROM plh.Vw_Vista_Consumo g
        INNER JOIN plh.Receta_detalle rd
            ON  CAST(rd.Id_Receta AS VARCHAR(50)) = CAST(g.ITEM AS VARCHAR(50))
            AND rd.Codigo_Item <> CAST(rd.Id_Receta AS VARCHAR(50))
            AND rd.DataAreaId  = (SELECT data_area_id FROM DataArea)
            AND rd.Modificador <> 1
        INNER JOIN plh.plh_cat_catalogo_productos cat
            ON  cat.cat_pro_codigo    = rd.Codigo_Item
            AND cat.cat_codigo_neg    = @CodigoNeg
            AND cat.cat_tienda_codigo IN (0, @TiendaCodigo)
            AND cat.cat_activo        = 1
        CROSS JOIN Rango r
        WHERE g.LC_UNIT   = @TiendaCodigo
          AND g.Cantidad  > 0
          AND g.LC_DOB   >= r.fecha_inicio
          AND g.LC_DOB    < r.fecha_fin
        GROUP BY g.LC_DOB, g.HOUR
    ),
    ConDiaSemana AS (
        SELECT
            CAST(
                CASE DATEPART(WEEKDAY, fecha_neg)
                    WHEN 1 THEN 7
                    ELSE DATEPART(WEEKDAY, fecha_neg) - 1
                END
            AS TINYINT) AS dia_semana,
            hora,
            cantidad
        FROM VentasBase
    ),
    VentasPorDiaHora AS (
        SELECT dia_semana, hora, SUM(cantidad) AS cantidad_hora
        FROM ConDiaSemana
        GROUP BY dia_semana, hora
    ),
    VentasPorDia AS (
        SELECT dia_semana, SUM(cantidad_hora) AS cantidad_dia
        FROM VentasPorDiaHora
        GROUP BY dia_semana
    )
    SELECT
        h.dia_semana,
        h.hora,
        CAST(
            CASE WHEN d.cantidad_dia > 0
                 THEN h.cantidad_hora / d.cantidad_dia
                 ELSE 0
            END
        AS DECIMAL(8,6)) AS porcentaje
    FROM VentasPorDiaHora h
    INNER JOIN VentasPorDia d ON d.dia_semana = h.dia_semana
);
GO

-- ─── SP: Calcular y persistir Motor del Mes ──────────────────────────────────
-- Inmutable: si ya existe para tienda+mes_proyectado → retorna error.

CREATE OR ALTER PROCEDURE [plh].[plh_mrf_CalcularMotorMes]
    @TiendaCodigo       INT,
    @CodigoNeg          NVARCHAR(10),
    @AnioProyectado     INT,
    @MesProyectado      INT,
    @AnioRef            INT,
    @MesRef             INT,
    @UsuarioCodigo      NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;

    BEGIN TRY
        IF EXISTS (
            SELECT 1 FROM plh.plh_fct_factor_sku
            WHERE fct_tienda_codigo   = @TiendaCodigo
              AND fct_codigo_neg      = @CodigoNeg
              AND fct_anio_proyectado = @AnioProyectado
              AND fct_mes_proyectado  = @MesProyectado
        )
        BEGIN
            RAISERROR('Ya existe un cálculo para esta tienda y mes proyectado. No se permite recalcular.', 16, 1);
            RETURN;
        END

        MERGE plh.plh_fct_factor_sku AS tgt
        USING (
            SELECT pro_codigo, factor_sku
            FROM plh.fn_plh_FactoresSKU(@TiendaCodigo, @CodigoNeg, @AnioRef, @MesRef)
        ) AS src
        ON  tgt.fct_tienda_codigo    = @TiendaCodigo
        AND tgt.fct_codigo_neg       = @CodigoNeg
        AND tgt.fct_pro_codigo       = src.pro_codigo
        AND tgt.fct_anio_proyectado  = @AnioProyectado
        AND tgt.fct_mes_proyectado   = @MesProyectado
        WHEN NOT MATCHED THEN
            INSERT (fct_codigo_neg, fct_tienda_codigo, fct_pro_codigo,
                    fct_anio_proyectado, fct_mes_proyectado,
                    fct_anio_referencia, fct_mes_referencia,
                    fct_factor_sku, fct_fecha_calculo, fct_usuario_calculo)
            VALUES (@CodigoNeg, @TiendaCodigo, src.pro_codigo,
                    @AnioProyectado, @MesProyectado,
                    @AnioRef, @MesRef,
                    src.factor_sku, GETDATE(), @UsuarioCodigo);

        MERGE plh.plh_pha_patron_horario AS tgt
        USING (
            SELECT dia_semana, hora, porcentaje
            FROM plh.fn_plh_PatronHorario(@TiendaCodigo, @CodigoNeg, @AnioRef, @MesRef)
        ) AS src
        ON  tgt.pha_tienda_codigo    = @TiendaCodigo
        AND tgt.pha_codigo_neg       = @CodigoNeg
        AND tgt.pha_anio_proyectado  = @AnioProyectado
        AND tgt.pha_mes_proyectado   = @MesProyectado
        AND tgt.pha_dia_semana       = src.dia_semana
        AND tgt.pha_hora             = src.hora
        WHEN NOT MATCHED THEN
            INSERT (pha_codigo_neg, pha_tienda_codigo,
                    pha_anio_proyectado, pha_mes_proyectado,
                    pha_dia_semana, pha_hora, pha_porcentaje,
                    pha_fecha_calculo, pha_usuario_calculo)
            VALUES (@CodigoNeg, @TiendaCodigo,
                    @AnioProyectado, @MesProyectado,
                    src.dia_semana, src.hora, src.porcentaje,
                    GETDATE(), @UsuarioCodigo);

        COMMIT TRANSACTION;

        SELECT COUNT(*) AS factores_calculados
        FROM plh.plh_fct_factor_sku
        WHERE fct_tienda_codigo   = @TiendaCodigo
          AND fct_codigo_neg      = @CodigoNeg
          AND fct_anio_proyectado = @AnioProyectado
          AND fct_mes_proyectado  = @MesProyectado;

    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

-- =============================================

CREATE OR ALTER PROCEDURE [plh].[plh_mrf_EliminarMotorMes]
    @TiendaCodigo   INT,
    @CodigoNeg      NVARCHAR(10),
    @AnioProyectado INT,
    @MesProyectado  INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM plh.plh_fct_factor_sku
    WHERE fct_tienda_codigo   = @TiendaCodigo
      AND fct_codigo_neg      = @CodigoNeg
      AND fct_anio_proyectado = @AnioProyectado
      AND fct_mes_proyectado  = @MesProyectado;

    DELETE FROM plh.plh_pha_patron_horario
    WHERE pha_tienda_codigo   = @TiendaCodigo
      AND pha_codigo_neg      = @CodigoNeg
      AND pha_anio_proyectado = @AnioProyectado
      AND pha_mes_proyectado  = @MesProyectado;
END;
GO
