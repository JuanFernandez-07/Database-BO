-- =============================================
-- Módulo: Horneadas
-- SPs: plh_hor_GuardarHorneada, plh_hor_DesactivarHorneada
-- Base de datos: sm_backoffice_op
-- =============================================

USE [sm_backoffice_op];
GO

CREATE OR ALTER PROCEDURE [plh].[plh_hor_GuardarHorneada]
    @CodigoNeg                  NVARCHAR(20),
    @TiendaCodigo               INT,
    @NumeroSecuencia            INT,
    @HoraInicio                 TIME(0),
    @HoraFin                    TIME(0),
    @AplicaPedidoCocina         BIT,
    @Activa                     BIT,
    @UsuarioCodigo              NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (
        SELECT 1 FROM plh.plh_hor_horneadas
        WHERE hor_codigo_neg       = @CodigoNeg
          AND hor_tienda_codigo    = @TiendaCodigo
          AND hor_numero_secuencia = @NumeroSecuencia
    )
    BEGIN
        INSERT INTO plh.plh_hor_horneadas (
            hor_codigo_neg, hor_tienda_codigo, hor_numero_secuencia,
            hor_hora_inicio, hor_hora_fin, hor_aplica_pedido_cocina,
            hor_activa, hor_fecha_creacion, hor_usuario_creacion_codigo,
            hor_fecha_modificacion, hor_usuario_modificacion_codigo
        )
        VALUES (
            @CodigoNeg, @TiendaCodigo, @NumeroSecuencia,
            @HoraInicio, @HoraFin, @AplicaPedidoCocina,
            @Activa, GETDATE(), @UsuarioCodigo,
            GETDATE(), @UsuarioCodigo
        );
    END
    ELSE
    BEGIN
        UPDATE plh.plh_hor_horneadas
        SET hor_hora_inicio                 = @HoraInicio,
            hor_hora_fin                    = @HoraFin,
            hor_aplica_pedido_cocina        = @AplicaPedidoCocina,
            hor_activa                      = @Activa,
            hor_fecha_modificacion          = GETDATE(),
            hor_usuario_modificacion_codigo = @UsuarioCodigo
        WHERE hor_codigo_neg       = @CodigoNeg
          AND hor_tienda_codigo    = @TiendaCodigo
          AND hor_numero_secuencia = @NumeroSecuencia;

        IF @@ROWCOUNT = 0
        BEGIN
            RAISERROR('Horneada no encontrada.', 16, 1);
            RETURN;
        END
    END

    INSERT INTO plh.plh_log_parametrizacion (
        log_codigo_neg, log_tienda_codigo, log_hor_numero_secuencia,
        log_usuario_codigo, log_fecha_hora, log_campo_modificado,
        log_valor_anterior, log_valor_nuevo
    )
    VALUES (
        @CodigoNeg, @TiendaCodigo, @NumeroSecuencia,
        @UsuarioCodigo, GETDATE(), 'UPSERT',
        NULL, CONCAT('SEQ:', @NumeroSecuencia, ' INICIO:', @HoraInicio, ' FIN:', @HoraFin)
    );

    SELECT @CodigoNeg AS hor_codigo_neg, @TiendaCodigo AS hor_tienda_codigo, @NumeroSecuencia AS hor_numero_secuencia;
END;
GO

-- =============================================

CREATE OR ALTER PROCEDURE [plh].[plh_hor_DesactivarHorneada]
    @CodigoNeg          NVARCHAR(20),
    @TiendaCodigo       INT,
    @NumeroSecuencia    INT,
    @UsuarioCodigo      NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE plh.plh_hor_horneadas
    SET hor_activa                      = 0,
        hor_fecha_modificacion          = GETDATE(),
        hor_usuario_modificacion_codigo = @UsuarioCodigo
    WHERE hor_codigo_neg       = @CodigoNeg
      AND hor_tienda_codigo    = @TiendaCodigo
      AND hor_numero_secuencia = @NumeroSecuencia;

    IF @@ROWCOUNT = 0
    BEGIN
        RAISERROR('Horneada no encontrada.', 16, 1);
        RETURN;
    END

    INSERT INTO plh.plh_log_parametrizacion (
        log_codigo_neg, log_tienda_codigo, log_hor_numero_secuencia,
        log_usuario_codigo, log_fecha_hora, log_campo_modificado,
        log_valor_anterior, log_valor_nuevo
    )
    VALUES (
        @CodigoNeg, @TiendaCodigo, @NumeroSecuencia,
        @UsuarioCodigo, GETDATE(), 'hor_activa',
        '1', '0'
    );
END;
GO
